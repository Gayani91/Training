echo "starting of the flow"
echo $(cat data.text) > randomtext.txt
echo "ending of the flow"
